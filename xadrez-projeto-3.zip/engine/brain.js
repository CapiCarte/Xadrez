/* Motor de xadrez (busca no estilo Stockfish): PVS, tabela de transposição, LMR, null-move não usado,
   quiescence, killers/history e avaliação por fase. Depende de chess.js (regras). */
/* Motor (busca no estilo Stockfish) ================= */
const V={p:100,n:320,b:330,r:500,q:900,k:0},INF=1e6,MATE=1e5,TO={};
let nodes=0,deadline=0,tt=new Map(),killers=[],hist_h={};
function evaluate(g){
  const b=g.board();let s=0,npm=0,bp={w:0,b:0},kings=[];
  for(let r=0;r<8;r++)for(let f=0;f<8;f++){
    const p=b[r][f];if(!p)continue;
    const w=p.color==='w',sg=w?1:-1,rr=w?7-r:r,cen=7-(Math.abs(f-3.5)+Math.abs(r-3.5));
    let v=V[p.type];
    if(p.type==='p')v+=rr*8+(rr>2?rr*rr:0)+((f===3||f===4)&&rr<4?4:0);
    else{ if(p.type!=='k')npm+=v;
      if(p.type==='n')v+=6*cen; else if(p.type==='b'){v+=4*cen;bp[p.color]++}
      else if(p.type==='r'){if(rr===6)v+=15}
      else if(p.type==='q')v+=1.5*cen;
      else kings.push([sg,cen]);}
    s+=sg*v;
  }
  const ph=Math.min(1,npm/6400);
  for(const[sg,cen]of kings)s+=sg*(ph*-6*cen+(1-ph)*6*cen);
  s+=30*((bp.w>=2)-(bp.b>=2));
  return Math.round(g.turn()==='w'?s:-s)+10;
}
function order(g,ms,ply,ttm){
  const t=g.turn();
  for(const m of ms){
    m.o=m.san===ttm?1e8:m.captured?1e6+V[m.captured]*10-V[m.piece]/10:m.promotion?9e5+V[m.promotion]
      :(killers[ply]&&killers[ply].includes(m.san))?8e5:(hist_h[t+m.from+m.to]||0);
  }
  return ms.sort((a,b)=>b.o-a.o);
}
const mv=m=>({from:m.from,to:m.to,promotion:m.promotion});
function qs(g,alpha,beta,q){
  if((++nodes&511)===0&&performance.now()>deadline)throw TO;
  const st=evaluate(g);if(st>=beta)return beta;if(st>alpha)alpha=st;if(q>6)return alpha;
  const ms=order(g,g.moves({verbose:true}).filter(m=>m.captured||m.promotion),0,null);
  for(const m of ms){g.move(mv(m));const sc=-qs(g,-beta,-alpha,q+1);g.undo();
    if(sc>=beta)return beta;if(sc>alpha)alpha=sc;}
  return alpha;
}
function search(g,d,alpha,beta,ply){
  if((++nodes&511)===0&&performance.now()>deadline)throw TO;
  const chk=g.in_check();if(chk)d++;
  if(d<=0)return qs(g,alpha,beta,0);
  if(ply>0&&g.in_draw())return 0;
  const key=g.fen().split(' ').slice(0,4).join(' '),e=tt.get(key);let ttm=null;
  if(e){ttm=e.m;if(e.d>=d&&ply>0){if(e.f===0)return e.s;if(e.f===1)alpha=Math.max(alpha,e.s);else beta=Math.min(beta,e.s);if(alpha>=beta)return e.s;}}
  const ms=order(g,g.moves({verbose:true}),Math.min(ply,60),ttm);
  if(!ms.length)return chk?-MATE+ply:0;
  let best=-INF,bm=null;const orig=alpha;
  for(let i=0;i<ms.length;i++){
    const m=ms[i],quiet=!m.captured&&!m.promotion;let sc;
    g.move(mv(m));
    if(i===0)sc=-search(g,d-1,-beta,-alpha,ply+1);
    else{
      const red=(i>=4&&d>=3&&quiet&&!chk&&!g.in_check())?1:0;
      sc=-search(g,d-1-red,-alpha-1,-alpha,ply+1);
      if(sc>alpha&&red)sc=-search(g,d-1,-alpha-1,-alpha,ply+1);
      if(sc>alpha&&sc<beta)sc=-search(g,d-1,-beta,-alpha,ply+1);
    }
    g.undo();
    if(sc>best){best=sc;bm=m.san}
    if(sc>alpha)alpha=sc;
    if(alpha>=beta){
      if(quiet){const k=killers[Math.min(ply,60)]=killers[Math.min(ply,60)]||[];if(k[0]!==m.san)k.unshift(m.san),k.length=Math.min(k.length,2);
        const h=g.turn()+m.from+m.to;hist_h[h]=(hist_h[h]||0)+d*d}
      break;}
  }
  if(Math.abs(best)<MATE-500){if(tt.size>200000)tt.clear();tt.set(key,{d,f:best<=orig?2:best>=beta?1:0,s:best,m:bm})}
  return best;
}
function root(g,d,ms,exact){
  let alpha=-INF;const res=[];
  for(let i=0;i<ms.length;i++){
    const m=ms[i];g.move(mv(m));let sc;
    if(g.in_threefold_repetition())sc=0;
    else if(exact||i===0)sc=-search(g,d-1,-INF,exact?INF:-alpha,1);
    else{sc=-search(g,d-1,-alpha-1,-alpha,1);if(sc>alpha)sc=-search(g,d-1,-INF,-alpha,1)}
    g.undo();res.push({sc,m});if(!exact&&sc>alpha)alpha=sc;
  }
  return res.sort((a,b)=>b.sc-a.sc);
}
function gauss(s){let u=0,v=0;while(!u)u=Math.random();v=Math.random();return s*Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}
function think(g,elo,ms_){
  const strong=elo>=2600,maxD=strong?40:elo<1400?1:elo<2000?2:3,sigma=strong?0:(2600-elo)/(elo<1000?4:6);
  nodes=0;killers=[];hist_h={};
  deadline=performance.now()+(ms_||(strong?1800+Math.min(1800,(elo-2600)*3):6000));
  const h0=g.history().length;let ms=order(g,g.moves({verbose:true}),0,null),res=ms.map(m=>({sc:0,m}));
  if(ms.length===1&&!ms_)return{m:ms[0],cp:0,raw:0};
  try{for(let d=1;d<=maxD;d++){const r=root(g,d,ms,!strong);res=r;ms=r.map(x=>x.m);if(strong&&Math.abs(r[0].sc)>MATE-200)break}}catch(x){if(x!==TO)throw x}finally{while(g.history().length>h0)g.undo()}
  let pick=res[0];
  if(sigma)pick=res.map(x=>({...x,n:x.sc+gauss(sigma)})).sort((a,b)=>b.n-a.n)[0];
  return{m:pick.m,cp:g.turn()==='w'?pick.sc:-pick.sc,raw:pick.sc,sec:res.length>1?res[1].sc:null};
}
