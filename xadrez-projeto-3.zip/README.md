# Meu Motor de Xadrez

- `engine/brain.js` – motor (busca estilo Stockfish, elo 200–3200)
- `web/` – interface (`index.html`, `styles.css`, `script.js`, `assets/` com as peças)
- `main.py` – servidor Flask opcional

## Rodar
- Direto: abra `web/index.html` no navegador (precisa de internet para carregar o chess.js).
- Com servidor: `pip install -r requirements.txt && python main.py` e abra http://localhost:8080
