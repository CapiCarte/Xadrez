"""Servidor estático do jogo. O motor roda no navegador (engine/brain.js).
Uso: python main.py  ->  http://localhost:8080   (ou abra web/index.html direto no navegador)"""
import os

from flask import Flask, send_from_directory

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE, "web"), static_url_path="")


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/engine/<path:name>")
def engine_files(name):
    return send_from_directory(os.path.join(BASE, "engine"), name)


@app.route("/manus-routes.json")
def route_manifest():
    return send_from_directory(BASE, "manus-routes.json")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")), debug=False)
