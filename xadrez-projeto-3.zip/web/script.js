/* Interface (jogar + analisar). Usa think() do engine/brain.js */
const $=id=>document.getElementById(id);
const boardElement=$("board"),statusElement=$("status");
const colorButtons=[...document.querySelectorAll(".color-button")];
const pieceNames={k:"king",q:"queen",r:"rook",b:"bishop",n:"knight",p:"pawn"};
const mvo=m=>({from:m.from,to:m.to,promotion:m.promotion});
let pending=null;
let mode="play",game=new Chess(),color="w",elo=1800,waiting=false,selected=null;

function drawBoard(grid,flip,sel,targets,onClick,badge,last){
    boardElement.innerHTML="";
    for(let d=0;d<64;d++){
        const bi=flip?63-d:d,r=Math.floor(bi/8),f=bi%8,name="abcdefgh"[f]+(8-r),piece=grid[r][f];
        const sq=document.createElement("div");
        sq.className="square "+(((Math.floor(d/8)+d%8)%2===0)?"light":"dark");
        if(last&&(last.from===name||last.to===name))sq.classList.add("last-move");
        if(sel===name)sq.classList.add("selected");
        if(targets&&targets.includes(name))sq.classList.add("legal-target");
        if(piece){const img=document.createElement("img");img.className="piece-image";img.alt=piece.type;
            img.src="assets/"+piece.color+"_"+pieceNames[piece.type]+".svg";sq.appendChild(img)}
        if(badge&&badge.sq===name){const b=document.createElement("img");b.className="badge";b.src=badge.src;b.alt="";sq.appendChild(b)}
        sq.addEventListener("click",()=>onClick&&onClick(name));
        boardElement.appendChild(sq);
    }
}

/* ---------- Jogar ---------- */
function playStatus(){
    if(game.in_checkmate())return"Xeque-mate!";
    if(game.in_stalemate())return"Afogamento!";
    if(game.game_over())return"Empate!";
    if(game.in_check())return"Xeque!";
    if(waiting)return"O motor está pensando...";
    return game.turn()===color?"Seu turno — escolha qualquer lance legal":"Turno do motor";
}
function lastPlayed(){const h=game.history({verbose:true});return h.length?h[h.length-1]:null}
function renderPlay(){
    const targets=selected?game.moves({square:selected,verbose:true}).map(m=>m.to):null;
    drawBoard(game.board(),color==="b",selected,targets,selectSquare,null,lastPlayed());
    showPromo();
    statusElement.textContent=playStatus();
    colorButtons.forEach(b=>b.classList.toggle("active",b.dataset.color===(color==="w"?"white":"black")));
    $("elo").value=elo;$("elo-label").textContent=elo>=3200?"Máximo":elo;
    const res=game.in_checkmate()?(game.turn()==="w"?"0-1":"1-0"):game.game_over()?"1/2-1/2":"*";
    const me="Jogador",bot="Motor ("+(elo>=3200?"máx":elo)+")";
    game.header("Event","Motor Xadrez","White",color==="w"?me:bot,"Black",color==="w"?bot:me,"Result",res);
    $("pgn-text").value=game.pgn();
}
function selectSquare(name){
    if(waiting||game.game_over()||game.turn()!==color)return;
    const p=game.get(name);
    if(selected===null){if(p&&p.color===color){selected=name;renderPlay()}return}
    if(selected===name){selected=null;return renderPlay()}
    if(p&&p.color===color){selected=name;return renderPlay()}
    const ms=game.moves({square:selected,verbose:true}).filter(m=>m.to===name);
    if(!ms.length){statusElement.textContent="Escolha um destino legal.";return}
    if(ms[0].promotion){pending={from:selected,to:name};return renderPlay()}
    game.move({from:selected,to:name});
    selected=null;renderPlay();botTurn();
}
/* Escolha da peça na promoção (estilo chess.com): dama, cavalo, torre, bispo */
function showPromo(){
    const old=$("promo-wrap");if(old)old.remove();
    if(!pending)return;
    const flip=color==="b",file="abcdefgh".indexOf(pending.to[0]),rank=+pending.to[1];
    const col=flip?7-file:file,row=flip?rank-1:8-rank,top=row===0;
    const sq=(boardElement.clientWidth-8)/8,off=boardElement.clientLeft+4;
    const wrap=document.createElement("div");wrap.id="promo-wrap";
    wrap.style.cssText="left:"+boardElement.offsetLeft+"px;top:"+boardElement.offsetTop+"px;width:"+boardElement.offsetWidth+"px;height:"+boardElement.offsetHeight+"px";
    wrap.addEventListener("click",e=>{if(e.target===wrap){pending=null;renderPlay()}});
    const box=document.createElement("div");box.id="promo-box";
    box.style.cssText="left:"+(off+col*sq)+"px;top:"+(off+(top?0:4*sq))+"px;width:"+sq+"px;height:"+(4*sq)+"px;flex-direction:"+(top?"column":"column-reverse");
    for(const t of ["q","n","r","b"]){
        const b=document.createElement("button");b.type="button";b.className="promo-btn";b.setAttribute("aria-label","Promover para "+t);
        const img=document.createElement("img");img.src="assets/"+color+"_"+pieceNames[t]+".svg";img.alt=t;b.appendChild(img);
        b.addEventListener("click",()=>{const m={from:pending.from,to:pending.to,promotion:t};pending=null;selected=null;game.move(m);renderPlay();botTurn()});
        box.appendChild(b);
    }
    wrap.appendChild(box);boardElement.parentElement.appendChild(wrap);
}
window.addEventListener("resize",showPromo);
function botTurn(){
    if(game.game_over()||game.turn()===color)return;
    waiting=true;renderPlay();
    setTimeout(()=>{
        try{const r=think(game,elo);game.move(mvo(r.m));
            $("engine-move").textContent=r.m.san;$("evaluation").textContent=fmt(r.cp)}
        catch(e){statusElement.textContent="Erro no motor: "+e.message}
        waiting=false;renderPlay();
    },50);
}
function fmt(cp){if(Math.abs(cp)>MATE-200){const n=Math.ceil((MATE-Math.abs(cp))/2);return(cp>0?"":"-")+"M"+n}return(cp>=0?"+":"")+(cp/100).toFixed(2)}
function newGame(){game=new Chess();selected=null;pending=null;tt.clear();$("engine-move").textContent="—";$("evaluation").textContent="0";renderPlay();botTurn()}
colorButtons.forEach(b=>b.addEventListener("click",()=>{if(waiting)return;color=b.dataset.color==="white"?"w":"b";newGame()}));
$("reset").addEventListener("click",()=>{if(!waiting)newGame()});
$("elo").addEventListener("input",e=>{elo=+e.target.value;$("elo-label").textContent=elo>=3200?"Máximo":elo});
$("pgn-button").addEventListener("click",()=>$("pgn-viewer").classList.toggle("hidden"));
$("close-pgn").addEventListener("click",()=>$("pgn-viewer").classList.add("hidden"));
$("copy-pgn").addEventListener("click",async()=>{const t=$("pgn-text");try{await navigator.clipboard.writeText(t.value)}catch(e){t.select();document.execCommand("copy")}});

/* ---------- Menu ⋯ ---------- */
function setMode(m){
    pending=null;showPromo();mode=m;$("menu").classList.add("hidden");
    $("play-panel").classList.toggle("hidden",m!=="play");$("analysis-panel").classList.toggle("hidden",m!=="analyze");
    $("m-play").classList.toggle("active",m==="play");$("m-analyze").classList.toggle("active",m==="analyze");
    if(m==="play")renderPlay();else renderAn();
}
$("kebab").addEventListener("click",e=>{e.stopPropagation();$("menu").classList.toggle("hidden")});
document.addEventListener("click",()=>$("menu").classList.add("hidden"));
$("m-play").addEventListener("click",()=>setMode("play"));
$("m-analyze").addEventListener("click",()=>setMode("analyze"));

/* ---------- Analisar (avalia cada posição com o motor) ---------- */
const AN={fens:[],sans:[],S:[],lab:[],acc:{w:null,b:null},ply:0,busy:false,ready:false};
const win=cp=>50+50*(2/(1+Math.exp(-0.00368208*Math.max(-1500,Math.min(1500,cp))))-1);
const LAB={
 brilliant:{name:"Brilhante",c:"#26c2a3",t:"!!"},great:{name:"Ótimo",c:"#5b8bb2",t:"!"},
 best:{name:"Melhor",c:"#96bc4b",i:"star"},excellent:{name:"Excelente",c:"#81b64c",i:"check"},
 good:{name:"Bom",c:"#95a7b5",i:"check"},book:{name:"Livro",c:"#a88865",i:"book"},
 inacc:{name:"Imprecisão",c:"#f7c631",t:"?!"},mistake:{name:"Erro",c:"#e58f2a",t:"?"},
 miss:{name:"Perdeu",c:"#ff7769",i:"x"},blunder:{name:"Gafe",c:"#ca3431",t:"??"}};
const ICON={};
for(const k in LAB){
    const L=LAB[k];let g="";
    if(L.t)g='<text x="16" y="22.5" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="900" font-size="'+(L.t.length>1?15:19)+'" fill="#fff">'+L.t.replace("?","?")+"</text>";
    else if(L.i==="star")g='<polygon points="16,6 19,13 26.5,13.6 20.8,18.5 22.6,26 16,22 9.4,26 11.2,18.5 5.5,13.6 13,13" fill="#fff"/>';
    else if(L.i==="check")g='<polyline points="9,17 14,22 23,11" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>';
    else if(L.i==="book")g='<rect x="7.5" y="10" width="7.5" height="12" rx="1" fill="#fff"/><rect x="17" y="10" width="7.5" height="12" rx="1" fill="#fff"/>';
    else g='<path d="M10.5 10.5L21.5 21.5M21.5 10.5L10.5 21.5" stroke="#fff" stroke-width="3.6" stroke-linecap="round"/>';
    const svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><circle cx="16" cy="16" r="15" fill="'+L.c+'" stroke="rgba(0,0,0,.35)" stroke-width="1.2"/>'+g+"</svg>";
    ICON[k]="data:image/svg+xml;utf8,"+encodeURIComponent(svg);
}
const MVAL={p:100,n:320,b:330,r:500,q:900,k:0};
function isSacrifice(fen,m){
    const g=new Chess(fen),x=g.move(mvo(m));
    if(!x||x.piece==="k"||x.piece==="p")return false;
    const pv=MVAL[x.piece],gain=x.captured?MVAL[x.captured]:0;
    if(pv-gain<150)return false;
    for(const c of g.moves({verbose:true}).filter(y=>y.to===x.to&&y.captured)){
        g.move(mvo(c));const recap=g.moves({verbose:true}).some(y=>y.to===x.to&&y.captured);g.undo();
        if(gain-pv+(recap?MVAL[c.piece]:0)<=-150)return true;
    }
    return false;
}
function classifyMove(k,prev){
    const S=AN.S,before=S[k].sc,after=-S[k+1].sc,wb=win(before),wa=win(after),drop=Math.max(0,wb-wa),best=S[k].best===AN.sans[k];
    if(k<8&&drop<=2)return{key:"book",drop};
    if((best||drop<=2)&&wb<85&&wa>=45&&isSacrifice(AN.fens[k],AN.moves[k]))return{key:"brilliant",drop};
    if(best&&S[k].sec!==null&&wb-win(S[k].sec)>=15&&wb<95)return{key:"great",drop};
    if(best||drop<=0.5)return{key:"best",drop};
    if(prev&&(prev==="mistake"||prev==="blunder")&&drop>=5&&drop<=20)return{key:"miss",drop};
    return{key:drop<=2?"excellent":drop<=5?"good":drop<=10?"inacc":drop<=20?"mistake":"blunder",drop};
}
function cleanPgn(t){
    t=t.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").replace(/\$\d+/g,"").trim();
    return t.replace(/^((?:\[[^\n]*\]\n)+)(?=[^\n])/,"$1\n"); // garante linha em branco entre cabeçalho e lances
}
async function runAnalysis(){
    if(AN.busy)return;
    let t=cleanPgn($("an-input").value);
    if(!t){$("an-msg").textContent="Cole um PGN primeiro.";return}
    if(/^https?:\/\/\S+$/i.test(t)){$("an-msg").textContent="Links não funcionam aqui (a página não acessa outros sites). No chess.com, abra a partida > Compartilhar > PGN, copie e cole o texto.";return}
    const i=t.search(/\n\s*\[Event\s/);if(i>0)t=t.slice(0,i);
    const g=new Chess();
    if(!g.load_pgn(t,{sloppy:true})&&!g.load_pgn(t.replace(/^(?:\[[^\n]*\]\s*\n)+/,""),{sloppy:true})){$("an-msg").textContent="Não consegui ler esse PGN. Confira se está completo.";return}
    const h=g.header(),moves=g.history({verbose:true});
    if(!moves.length){$("an-msg").textContent="Esse PGN não tem lances.";return}
    const p=new Chess();if(h.FEN)p.load(h.FEN);
    AN.fens=[p.fen()];AN.sans=[];AN.tos=[];AN.moves=moves;
    for(const m of moves){p.move(mvo(m));AN.fens.push(p.fen());AN.sans.push(m.san);AN.tos.push(m.to)}
    AN.S=[];AN.busy=true;AN.ready=false;AN.ply=0;$("an-run").disabled=true;$("an-result").classList.add("hidden");
    for(let k=0;k<AN.fens.length;k++){
        $("an-msg").textContent="Analisando posição "+(k+1)+" de "+AN.fens.length+"…";
        await new Promise(r=>setTimeout(r,20));
        const q=new Chess(AN.fens[k]);
        if(!q.moves().length)AN.S.push({sc:q.in_checkmate()?-MATE:0,best:null});
        else{const r=think(q,3200,450);AN.S.push({sc:r.raw,best:r.m.san,sec:r.sec})}
    }
    const sum={w:[],b:[]};AN.lab=[];
    for(let k=0;k<AN.sans.length;k++){
        const side=AN.fens[k].split(" ")[1],L=classifyMove(k,k?AN.lab[k-1].key:null);
        AN.lab.push(L);
        sum[side].push(Math.max(0,Math.min(100,103.1668*Math.exp(-0.04354*L.drop)-3.1669)));
    }
    const avg=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length)+"%":"—";
    $("acc-w").textContent=avg(sum.w);$("acc-b").textContent=avg(sum.b);
    AN.busy=false;AN.ready=true;$("an-run").disabled=false;$("an-msg").textContent="Análise pronta ("+AN.sans.length+" lances). Toque num lance para ver a posição.";
    $("an-result").classList.remove("hidden");renderAn();
}
const whiteCp=k=>AN.fens[k].split(" ")[1]==="w"?AN.S[k].sc:-AN.S[k].sc;
function renderAn(){
    if(!AN.ready){drawBoard(new Chess().board(),false,null,null,null);statusElement.textContent="Análise";return}
    const k=AN.ply,g=new Chess(AN.fens[k]);
    drawBoard(g.board(),false,null,null,null,k>0?{sq:AN.tos[k-1],src:ICON[AN.lab[k-1].key]}:null,k>0?AN.moves[k-1]:null);
    statusElement.textContent="Análise — lance "+k+" de "+AN.sans.length;
    // gráfico
    const n=AN.fens.length-1,W=280,H=60;let pts="";
    for(let i=0;i<=n;i++){const cp=Math.max(-600,Math.min(600,whiteCp(i)));pts+=(n?i*W/n:0).toFixed(1)+","+(H/2-cp/600*(H/2-3)).toFixed(1)+" "}
    const cx=n?k*W/n:0;
    $("an-graph").innerHTML='<line x1="0" x2="'+W+'" y1="30" y2="30" stroke="#91a99b" stroke-opacity=".4"/><polyline fill="none" stroke="#28d17c" stroke-width="2" points="'+pts+'"/><line x1="'+cx+'" x2="'+cx+'" y1="0" y2="'+H+'" stroke="#f2c94c" stroke-width="2"/>';
    // detalhe
    let d="Posição inicial · "+fmt(whiteCp(0));
    if(k>0){const L=AN.lab[k-1],num=Math.ceil(k/2)+(k%2?".":"...");
        d=num+" "+AN.sans[k-1]+ ' <img class="ic" src="'+ICON[L.key]+'" alt=""> <strong style="color:'+LAB[L.key].c+'">'+LAB[L.key].name+"</strong> · "+fmt(whiteCp(k))+
          (AN.S[k-1].best&&AN.S[k-1].best!==AN.sans[k-1]?"<br>Melhor: <strong>"+AN.S[k-1].best+"</strong>":"")}
    $("an-detail").innerHTML=d;
    // lista
    let html="";
    for(let i=0;i<AN.sans.length;i+=2){
        const cell=j=>j<AN.sans.length?'<span class="mv'+(AN.ply===j+1?" cur":"")+'" data-p="'+(j+1)+'">'+AN.sans[j]+'<img class="ic" src="'+ICON[AN.lab[j].key]+'" alt="">'+"</span>":"<span></span>";
        html+='<div class="an-row"><span>'+(i/2+1)+"</span>"+cell(i)+cell(i+1)+"</div>";
    }
    $("an-list").innerHTML=html;
    $("an-list").querySelectorAll(".mv").forEach(el=>el.addEventListener("click",()=>{AN.ply=+el.dataset.p;renderAn()}));
    const cur=$("an-list").querySelector(".cur");if(cur)cur.scrollIntoView({block:"nearest"});
}
const goAn=n=>{if(AN.ready){AN.ply=Math.max(0,Math.min(AN.sans.length,n));renderAn()}};
$("an-run").addEventListener("click",runAnalysis);
$("a-first").addEventListener("click",()=>goAn(0));$("a-prev").addEventListener("click",()=>goAn(AN.ply-1));
$("a-next").addEventListener("click",()=>goAn(AN.ply+1));$("a-last").addEventListener("click",()=>goAn(AN.sans.length));
renderPlay();
