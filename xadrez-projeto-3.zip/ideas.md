# Direção visual — Motor Xadrez

## Theme Name
**Tabuleiro noturno** — uma página utilitária, direta e silenciosa para baixar um arquivo de código de xadrez.

**Probabilidade:** 0.04

## Direção escolhida
- **Movimento:** editorial técnico minimalista.
- **Princípios:** clareza imediata, uma ação principal, contraste alto e nenhuma distração.
- **Cores:** azul-marinho quase preto como campo; marfim para o conteúdo; verde-lima discreto para a ação de download.
- **Layout:** um único cartão central, responsivo, com nome do arquivo e botão de download.
- **Elemento de assinatura:** um ícone geométrico de cavalo de xadrez dentro de um quadrado sólido.
- **Interação:** estados de hover e foco evidentes, sem animações necessárias.
- **Tipografia:** sistema sem serifa, com números e hash em fonte monoespaçada.
- **Essência da marca:** ferramenta pequena, confiável e pronta para uso.
- **Tom:** objetivo e técnico.
- **Wordmark:** “Motor Xadrez”.
- **Cor de assinatura:** #C9F36B.

A página hospeda apenas o arquivo enviado pelo usuário. O ZIP é copiado byte a byte e não é alterado nem descompactado.
